
import React, { useState, useRef, useMemo } from 'react';
import { NetworkSegment, NetworkType, ProjectStatus, NetworkPoint, PointType } from '../types';
import { STATUS_COLORS } from '../constants';

interface NetworkMapProps {
  segments: NetworkSegment[];
  points: NetworkPoint[];
  selectedType: NetworkType | 'ALL';
  onSegmentClick: (segment: NetworkSegment) => void;
  onPointClick: (point: NetworkPoint) => void;
}

type MapTheme = 'SATELLITE' | 'STREET' | 'DARK_ENGINEERING';

const NetworkMap: React.FC<NetworkMapProps> = ({ segments, points, selectedType, onSegmentClick, onPointClick }) => {
  const [theme, setTheme] = useState<MapTheme>('DARK_ENGINEERING');
  const [zoom, setZoom] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  const bounds = useMemo(() => {
    if (segments.length === 0 && points.length === 0) {
      return { minX: 0, minY: 0, maxX: 1000, maxY: 800, rangeX: 1000, rangeY: 800 };
    }
    const allX = [
      ...segments.flatMap(s => [s.startNode.x, s.endNode.x]),
      ...points.map(p => p.location.x)
    ];
    const allY = [
      ...segments.flatMap(s => [s.startNode.y, s.endNode.y]),
      ...points.map(p => p.location.y)
    ];
    const minX = Math.min(...allX);
    const maxX = Math.max(...allX);
    const minY = Math.min(...allY);
    const maxY = Math.max(...allY);
    
    const paddingX = (maxX - minX) * 0.1 || 100;
    const paddingY = (maxY - minY) * 0.1 || 100;
    
    return {
      minX: minX - paddingX,
      minY: minY - paddingY,
      maxX: maxX + paddingX,
      maxY: maxY + paddingY,
      rangeX: (maxX - minX) + (paddingX * 2),
      rangeY: (maxY - minY) + (paddingY * 2)
    };
  }, [segments, points]);

  const transformX = (x: number) => ((x - bounds.minX) / bounds.rangeX) * 1000;
  const transformY = (y: number) => 800 - (((y - bounds.minY) / bounds.rangeY) * 800);

  const renderPointIcon = (point: NetworkPoint) => {
    const color = STATUS_COLORS[point.status];
    const tx = transformX(point.location.x);
    const ty = transformY(point.location.y);
    
    switch (point.type) {
      case PointType.MANHOLE:
        return (
          <g>
            <circle cx={tx} cy={ty} r="10" fill="white" stroke={color} strokeWidth="3" className="hover:r-12 transition-all shadow-lg" />
            <circle cx={tx} cy={ty} r="4" fill={color} />
          </g>
        );
      case PointType.VALVE:
        return <rect x={tx - 6} y={ty - 6} width="12" height="12" fill={color} stroke="white" strokeWidth="1" className="hover:scale-125 transform origin-center transition-all" />;
      case PointType.FIRE_HYDRANT:
        return <path d={`M ${tx} ${ty-8} L ${tx+7} ${ty+5} L ${tx-7} ${ty+5} Z`} fill={color} stroke="white" strokeWidth="1" />;
      default:
        return <circle cx={tx} cy={ty} r="6" fill={color} stroke="white" strokeWidth="2" />;
    }
  };

  const LegendItem = ({ color, label, iconType }: { color: string, label: string, iconType?: 'line' | 'rect' | 'circle' | 'manhole' | 'triangle' }) => (
    <div className="flex items-center gap-2">
      {iconType === 'line' && <div className={`w-6 h-1 rounded-full`} style={{ backgroundColor: color }}></div>}
      {iconType === 'rect' && <div className="w-3 h-3 border border-white" style={{ backgroundColor: color }}></div>}
      {iconType === 'triangle' && <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-bottom-[10px]" style={{ borderBottomColor: color }}></div>}
      {iconType === 'manhole' && (
        <div className="w-4 h-4 rounded-full border-2 bg-white flex items-center justify-center" style={{ borderColor: color }}>
          <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }}></div>
        </div>
      )}
      {iconType === 'circle' && <div className="w-3 h-3 rounded-full border border-white" style={{ backgroundColor: color }}></div>}
      <span className="text-[10px] font-black text-slate-600">{label}</span>
    </div>
  );

  return (
    <div className="bg-white rounded-3xl shadow-2xl p-6 w-full overflow-hidden relative border border-slate-200" ref={containerRef}>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h3 className="text-2xl font-black text-slate-800 tracking-tight">التخطيط المتري (UTM Zone 37N)</h3>
          <p className="text-xs text-slate-400 font-bold mt-1">نظام إحداثيات عالمي متوافق مع أجهزة الـ GPS المساحية</p>
        </div>
        
        <div className="flex gap-2">
          <button onClick={() => setZoom(prev => Math.min(prev + 0.2, 5))} className="w-10 h-10 bg-slate-100 text-slate-800 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm"><i className="fas fa-plus"></i></button>
          <button onClick={() => setZoom(prev => Math.max(prev - 0.2, 0.5))} className="w-10 h-10 bg-slate-100 text-slate-800 rounded-xl hover:bg-blue-600 hover:text-white transition-all shadow-sm"><i className="fas fa-minus"></i></button>
        </div>
      </div>
      
      <div className="relative w-full aspect-[21/9] border border-slate-200 rounded-3xl overflow-hidden bg-slate-900 shadow-inner">
        <div className="absolute top-4 right-4 z-20 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 flex items-center gap-2">
           <div className={`w-2 h-2 rounded-full ${selectedType === NetworkType.WATER ? 'bg-blue-500' : selectedType === NetworkType.SEWAGE ? 'bg-amber-600' : 'bg-slate-400'}`}></div>
           <span className="text-[10px] text-white font-black">
             {selectedType === 'ALL' ? 'الشبكة الموحدة' : selectedType === 'WATER' ? 'شبكة المياه' : 'شبكة الصرف'}
           </span>
        </div>

        <svg 
          viewBox="0 0 1000 800" 
          className="w-full h-full relative z-10 transition-transform duration-300 ease-out"
          style={{ transform: `scale(${zoom}) translate(${offset.x}px, ${offset.y}px)`, cursor: 'crosshair' }}
        >
          <defs>
            <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M 100 0 L 0 0 0 100" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="1"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />

          {segments.filter(s => selectedType === 'ALL' || s.type === selectedType).map((segment) => (
            <g key={segment.id} className="cursor-pointer group/line" onClick={() => onSegmentClick(segment)}>
              <line
                x1={transformX(segment.startNode.x)} y1={transformY(segment.startNode.y)}
                x2={transformX(segment.endNode.x)} y2={transformY(segment.endNode.y)}
                stroke={STATUS_COLORS[segment.status]}
                strokeWidth={segment.type === NetworkType.WATER ? "4" : "7"}
                strokeLinecap="round"
                className="transition-all duration-300 group-hover/line:stroke-white group-hover/line:stroke-[10px]"
              />
            </g>
          ))}

          {points.filter(p => {
            if (selectedType === 'ALL') return true;
            const isWaterPoint = [PointType.VALVE, PointType.FIRE_HYDRANT, PointType.WATER_HOUSE_CONNECTION].includes(p.type);
            return selectedType === NetworkType.WATER ? isWaterPoint : !isWaterPoint;
          }).map((point) => (
            <g key={point.id} className="cursor-pointer group/point" onClick={(e) => { e.stopPropagation(); onPointClick(point); }}>
              {renderPointIcon(point)}
              <text 
                x={transformX(point.location.x)} 
                y={transformY(point.location.y) - 20} 
                textAnchor="middle" 
                className="text-[9px] fill-slate-400 font-bold opacity-0 group-hover/point:opacity-100 transition-opacity pointer-events-none"
              >
                {point.name}
              </text>
            </g>
          ))}
        </svg>

        <div className="absolute bottom-6 left-6 z-30 bg-slate-900/80 backdrop-blur-md px-4 py-3 rounded-2xl border border-white/10 text-[10px] text-white font-mono shadow-2xl">
           <div className="flex flex-col gap-1">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                <span className="text-green-400 font-black">UTM PROJECTION ACTIVE</span>
              </div>
              <div className="flex gap-4 mt-1">
                <span>ZONE: 37 North</span>
                <span className="text-slate-500">|</span>
                <span>UNIT: Meters (m)</span>
              </div>
           </div>
        </div>
      </div>

      {/* مفتاح الخريطة الديناميكي */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 mt-6 bg-slate-50 p-4 rounded-2xl border border-slate-100">
        
        {/* العناصر المشتركة */}
        {(selectedType === 'ALL' || selectedType === NetworkType.WATER) && (
          <LegendItem color="#2563eb" label="خطوط مياه" iconType="line" />
        )}
        
        {(selectedType === 'ALL' || selectedType === NetworkType.SEWAGE) && (
          <LegendItem color="#d97706" label="خطوط انحدار" iconType="line" />
        )}

        {/* عناصر المياه */}
        {(selectedType === NetworkType.WATER || selectedType === 'ALL') && (
          <>
            <LegendItem color="#3b82f6" label="محابس" iconType="rect" />
            <LegendItem color="#ef4444" label="حنفيات حريق" iconType="circle" />
            <LegendItem color="#60a5fa" label="توصيلات منزلية مياه" iconType="circle" />
          </>
        )}

        {/* عناصر الصرف */}
        {(selectedType === NetworkType.SEWAGE || selectedType === 'ALL') && (
          <>
            <LegendItem color="#92400e" label="مناهل" iconType="manhole" />
            <LegendItem color="#b45309" label="غرف تفتيش" iconType="circle" />
          </>
        )}

        {/* مؤشر الحالة (عام) */}
        <div className="flex items-center gap-2 border-r border-slate-200 pr-4">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-[10px] font-black text-slate-400 uppercase">GPS LIVE</span>
        </div>
      </div>
    </div>
  );
};

export default NetworkMap;
