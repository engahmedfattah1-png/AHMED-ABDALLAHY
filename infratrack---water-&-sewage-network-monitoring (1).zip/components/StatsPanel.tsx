
import React from 'react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';
import { NetworkSegment, NetworkPoint, NetworkType, ProjectStatus } from '../types';

interface StatsPanelProps {
  segments: NetworkSegment[];
  points: NetworkPoint[];
  networkType: NetworkType | 'ALL';
}

const StatsPanel: React.FC<StatsPanelProps> = ({ segments, points, networkType }) => {
  // حسابات الأطوال ونسبة الإنجاز الكلية
  const totalLength = segments.reduce((acc, curr) => acc + curr.length, 0);
  const completedLength = segments.reduce((acc, curr) => acc + (curr.length * curr.completionPercentage / 100), 0);
  const overallProgress = totalLength > 0 ? Math.round((completedLength / totalLength) * 100) : 0;

  // بيانات مخطط نسبة الإنجاز الكلية
  const progressData = [
    { name: 'منفذ', value: overallProgress },
    { name: 'متبقي', value: 100 - overallProgress },
  ];

  // حسابات حالات العناصر الفنية (نقاط الشبكة)
  const pointsCompleted = points.filter(p => p.status === ProjectStatus.COMPLETED).length;
  const pointsInProgress = points.filter(p => p.status === ProjectStatus.IN_PROGRESS).length;
  const pointsPending = points.filter(p => p.status === ProjectStatus.PENDING).length;

  // بيانات مخطط العناصر الفنية
  const pointsData = [
    { name: 'منفذ', value: pointsCompleted, color: '#10b981' }, // أخضر
    { name: 'جاري', value: pointsInProgress, color: '#f59e0b' }, // برتقالي
    { name: 'متبقي', value: pointsPending, color: '#e2e8f0' },    // رمادي
  ].filter(d => d.value > 0);

  const typeLabel = networkType === 'ALL' ? 'الشبكة الموحدة' : networkType === NetworkType.WATER ? 'شبكة المياه' : 'شبكة الصرف';
  const mainChartColors = networkType === NetworkType.WATER ? ['#2563eb', '#f1f5f9'] : networkType === NetworkType.SEWAGE ? ['#d97706', '#f1f5f9'] : ['#64748b', '#f1f5f9'];

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      {/* 1. بطاقة النسبة الكلية */}
      <div className="bg-slate-900 rounded-[32px] shadow-2xl p-6 relative flex items-center overflow-hidden border border-white/10 group">
        <div className="flex-1 z-10">
          <h4 className="text-blue-400 font-black text-[10px] uppercase tracking-widest mb-1">نسبة الإنجاز الكلية</h4>
          <div className="text-5xl font-black text-white tabular-nums">{overallProgress}<span className="text-xl text-blue-500">%</span></div>
          <p className="text-[9px] text-slate-400 font-bold mt-2 leading-relaxed">بناءً على الأطوال المعتمدة</p>
        </div>
        
        <div className="w-28 h-28 relative shrink-0 z-10">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={progressData}
                cx="50%"
                cy="50%"
                innerRadius={30}
                outerRadius={40}
                paddingAngle={5}
                dataKey="value"
                startAngle={90}
                endAngle={450}
              >
                {progressData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={mainChartColors[index % mainChartColors.length]} stroke="none" />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex items-center justify-center">
             <i className={`fas ${overallProgress === 100 ? 'fa-check-circle text-green-500' : 'fa-bolt text-blue-500'} text-lg opacity-30`}></i>
          </div>
        </div>
        <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-blue-600/10 rounded-full blur-3xl group-hover:bg-blue-600/20 transition-all"></div>
      </div>

      {/* 2. بطاقة الأطوال */}
      <div className="bg-white rounded-[32px] shadow-sm p-7 border border-slate-100 transition-all hover:shadow-md">
        <h4 className="text-slate-400 font-black text-[10px] uppercase tracking-widest mb-3 flex items-center gap-2">
          <i className="fas fa-ruler-horizontal text-blue-500"></i> إجمالي أطوال {typeLabel}
        </h4>
        <div className="text-3xl font-black text-slate-900 mb-4">{Math.round(totalLength).toLocaleString()} <span className="text-xs text-slate-400 font-bold">متر</span></div>
        <div className="pt-2">
          <div className="flex justify-between text-[10px] font-black mb-2 text-slate-500">
            <span>المنفذ: {Math.round(completedLength).toLocaleString()} م</span>
            <span>{overallProgress}%</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
            <div 
              className={`h-full transition-all duration-1000 ${networkType === NetworkType.WATER ? 'bg-blue-600' : 'bg-amber-600'}`} 
              style={{ width: `${overallProgress}%` }}
            ></div>
          </div>
        </div>
      </div>

      {/* 3. بطاقة تعداد العناصر الفنية مع المخطط البياني */}
      <div className="bg-white rounded-[32px] shadow-sm p-6 border border-slate-100 transition-all hover:shadow-md flex items-center gap-4">
        <div className="flex-1">
          <h4 className="text-slate-400 font-black text-[10px] uppercase tracking-widest mb-2 flex items-center gap-2">
            <i className="fas fa-map-marker-alt text-amber-500"></i> تعداد العناصر الفنية
          </h4>
          <div className="text-3xl font-black text-slate-900 mb-4">{points.length} <span className="text-xs text-slate-400 font-bold">عنصر</span></div>
          
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-black text-green-600">منفذ</span>
              <span className="text-[10px] font-bold text-slate-700">{pointsCompleted}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-black text-amber-500">جاري</span>
              <span className="text-[10px] font-bold text-slate-700">{pointsInProgress}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-black text-slate-300">مخطط</span>
              <span className="text-[10px] font-bold text-slate-700">{pointsPending}</span>
            </div>
          </div>
        </div>

        <div className="w-24 h-24 relative shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pointsData.length > 0 ? pointsData : [{ name: 'خالي', value: 1, color: '#f1f5f9' }]}
                cx="50%"
                cy="50%"
                innerRadius={25}
                outerRadius={35}
                paddingAngle={2}
                dataKey="value"
              >
                {pointsData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                ))}
                {pointsData.length === 0 && <Cell fill="#f1f5f9" stroke="none" />}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
             <span className="text-[9px] font-black text-slate-400">{points.length}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsPanel;
